<?php
include_once 'conexao.php';

//$nome = filter_input(INPUT_GET, 'nome', FILTER_SANITIZE_STRING);
//echo "Nome: $nome<br>";

$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
$mensagem = filter_input(INPUT_POST, 'mensagem', FILTER_SANITIZE_STRING);

//echo "Nome: $nome<br>";
//echo "E-mail: $email<br>";
//echo "Mensagem: $mensagem<br>";

$result_usuario = "INSERT INTO usuarios (nome, email, mensagem) VALUES ('$nome', '$email', '$mensagem')";

$resultado_usuario = mysqli_query($conn, $result_usuario);

if(mysqli_insert_id($conn)){
	echo "Usuário cadastrado com sucesso";
}else{
	echo "Erro ao cadastrar o usuário";
}
